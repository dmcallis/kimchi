(function () {
  'use strict';

  var Foxx = require('org/arangodb/foxx'),
    Repository;

  Repository = Foxx.Repository.extend({
    // Add your custom methods here
  });

  exports.Repository = Repository;
}());

